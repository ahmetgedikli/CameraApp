package com.example.ahmet_gedikli_final

import android.graphics.Bitmap
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class StorageModel : ViewModel() {

}